#include <iostream>
#include "TennisPlayer.h"

using namespace std;

int main() {

	TennisPlayer tennisPlayer1("Ivan", 1000, 10);
	tennisPlayer1.Print();
	

	return 0;
}